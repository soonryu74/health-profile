import { useMemo, useState, useEffect, useRef } from "react";
import Cite from "./Cite";
import { INDICATORS, IND_BY_DOMAIN, DOMAINS_ALL, SIDOS, SGG_ALL, SGG_BY_SIDO, fmt, val, label, RBY , isSurvey, HC_POOL, sidoPoolOf, slopeOf, TREND_START } from "../data";
import ExportButtons from "./ExportButtons";
import { clientXY } from "./svgUtil";

/* 연관지표 탐색: 두 지표의 산점도 + 피어슨·스피어만·켄달 상관(유의성), 연도 애니메이션 — CIAT 심층분석 1 대응 */
function pearson(xs, ys) { const n = xs.length; if (n < 3) return null; const mx = xs.reduce((a, b) => a + b, 0) / n, my = ys.reduce((a, b) => a + b, 0) / n; let sxy = 0, sxx = 0, syy = 0; for (let i = 0; i < n; i++) { sxy += (xs[i] - mx) * (ys[i] - my); sxx += (xs[i] - mx) ** 2; syy += (ys[i] - my) ** 2; } return sxx && syy ? sxy / Math.sqrt(sxx * syy) : null; }
function ranks(a) { const idx = a.map((v, i) => [v, i]).sort((p, q) => p[0] - q[0]); const r = new Array(a.length); let i = 0; while (i < idx.length) { let j = i; while (j + 1 < idx.length && idx[j + 1][0] === idx[i][0]) j++; const avg = (i + j) / 2 + 1; for (let k = i; k <= j; k++) r[idx[k][1]] = avg; i = j + 1; } return r; }
function kendall(xs, ys) { const n = xs.length; if (n < 3) return null; let c = 0, d = 0, tx = 0, ty = 0; for (let i = 0; i < n; i++) for (let j = i + 1; j < n; j++) { const a = Math.sign(xs[i] - xs[j]), b = Math.sign(ys[i] - ys[j]); if (a === 0 && b === 0) continue; if (a === 0) tx++; else if (b === 0) ty++; else if (a === b) c++; else d++; } const den = Math.sqrt((c + d + tx) * (c + d + ty)); return den ? (c - d) / den : null; }
// 정규분포 양측 p (근사)
function pnorm2(z) { const t = 1 / (1 + 0.2316419 * Math.abs(z)); const dnorm = Math.exp(-z * z / 2) / Math.sqrt(2 * Math.PI); const p = dnorm * (0.31938153 * t - 0.356563782 * t ** 2 + 1.781477937 * t ** 3 - 1.821255978 * t ** 4 + 1.330274429 * t ** 5); return 2 * p; }
function pPearson(r, n) { if (r == null || n < 4 || Math.abs(r) >= 1) return r == null ? null : 0; const t = r * Math.sqrt((n - 2) / (1 - r * r)); return pnorm2(t * (1 - 1 / (4 * (n - 2)))); }   // t → 정규 근사(대표본)
function pKendall(tau, n) { if (tau == null || n < 4) return null; const z = 3 * tau * Math.sqrt(n * (n - 1)) / Math.sqrt(2 * (2 * n + 5)); return pnorm2(z); }

const Sel = ({ value, onChange }) => (
  <select value={value} onChange={(e) => onChange(e.target.value)} style={{ maxWidth: 260 }}>
    {DOMAINS_ALL.map((d) => <optgroup key={d} label={d}>{(IND_BY_DOMAIN[d] || []).map((i) => <option key={i.id} value={i.id}>{i.name}</option>)}</optgroup>)}
  </select>
);

export default function CorrelationView({ setTip }) {
  const [xId, setXId] = useState("DT_H_SM");
  const [yId, setYId] = useState("HLE_HLE");
  const [level, setLevel] = useState("sgg");
  const [sidoF, setSidoF] = useState("all");
  const [item, setItem] = useState("std");
  const [yMode, setYMode] = useState("value");   // value: 그해 값 · slope: 2015년 이후 연간 변화(직선 기울기)
  const xi = INDICATORS.find((i) => i.id === xId), yi = INDICATORS.find((i) => i.id === yId);
  const yLast = yi.years[yi.years.length - 1];
  const slopeOk = yi.years[0] <= TREND_START && yLast - TREND_START >= 4;
  const ySlope = yMode === "slope" && slopeOk;
  const years = useMemo(() => (ySlope ? xi.years : xi.years.filter((y) => yi.years.includes(y))), [xi, yi, ySlope]);
  const yUnit = ySlope ? (yi.unit === "%" ? "%p/년" : `${yi.unit}/년`) : yi.unit;
  const yName = ySlope ? `${yi.name} 연간 변화(${TREND_START}~${yLast})` : yi.name;
  const slopeMap = useMemo(() => (ySlope ? new Map() : null), [ySlope, yi, item]);
  const yv = (y, c) => { if (!ySlope) return val(yi, item, y, c); if (!slopeMap.has(c)) slopeMap.set(c, slopeOf(yi, item, c, TREND_START, yLast)); return slopeMap.get(c); };
  const preset = () => { setXId("K_ECO_FIN"); setYId("DT_H_OBE_OBE"); setYMode("slope"); setLevel("sgg"); setSidoF("all"); setItem("std"); setPlay(false); setTimeout(() => setYear(2014), 0); };
  const [year, setYear] = useState(years[years.length - 1]);
  useEffect(() => { if (!years.includes(year)) setYear(years[years.length - 1]); }, [years]);
  const [play, setPlay] = useState(false);
  useEffect(() => { if (!play) return; const t = setInterval(() => setYear((y) => { const i = years.indexOf(y); return years[(i + 1) % years.length]; }), 900); return () => clearInterval(t); }, [play, years]);
  // 두 지표가 모두 지역사회건강조사면 조사 단위 258곳, 하나라도 시군구 자료면 시군구 229곳에서 짝을 짓는다
  const both = isSurvey(xi) && isSurvey(yi);
  const pool = level === "sido" ? SIDOS : sidoF === "all" ? (both ? HC_POOL : SGG_ALL) : (both ? sidoPoolOf(xi, sidoF) : SGG_BY_SIDO[sidoF]);
  const pts = useMemo(() => pool.map((r) => ({ r, x: val(xi, item, year, r.c), y: yv(year, r.c) })).filter((p) => p.x != null && p.y != null), [pool, xi, yi, item, year, ySlope]);
  const xs = pts.map((p) => p.x), ys = pts.map((p) => p.y), n = pts.length;
  const rP = pearson(xs, ys), rS = pearson(ranks(xs), ranks(ys)), tK = kendall(xs, ys);
  const pP = pPearson(rP, n), pS = pPearson(rS, n), pK = pKendall(tK, n);
  // 회귀선
  const mx = xs.reduce((a, b) => a + b, 0) / (n || 1), my = ys.reduce((a, b) => a + b, 0) / (n || 1);
  const slope = n > 1 ? xs.reduce((a, x, i) => a + (x - mx) * (ys[i] - my), 0) / (xs.reduce((a, x) => a + (x - mx) ** 2, 0) || 1) : 0;
  // 컨테이너 폭에 맞춰 SVG 크기 결정(글자 크기 고정 → 데스크톱/모바일 모두 읽기 좋게)
  const wrapRef = useRef(null);
  const [cw, setCw] = useState(640);
  useEffect(() => { const el = wrapRef.current; if (!el) return; const ro = new ResizeObserver(() => setCw(el.clientWidth || 640)); ro.observe(el); setCw(el.clientWidth || 640); return () => ro.disconnect(); }, []);
  const W = Math.max(340, cw), narrowChart = W < 560;
  const H = narrowChart ? Math.round(W * 1.05) : Math.round(Math.min(480, Math.max(300, W * 0.5)));
  const L = 56, R = level === "sido" ? 30 : 18, T = 20, B = 46;
  // 축 범위: 데이터 양끝에 여백을 둬 점·지역명이 테두리에 붙거나 잘리지 않게
  const padded = (a) => {
    const lo0 = Math.min(...a), hi0 = Math.max(...a), sp = hi0 - lo0 || Math.abs(hi0) || 1;
    return [lo0 - sp * 0.08, hi0 + sp * 0.08];
  };
  const [xlo, xhi] = n ? padded(xs) : [0, 1];
  const [ylo, yhi] = n ? padded(ys) : [0, 1];
  const px = (v) => L + (W - L - R) * ((v - xlo) / ((xhi - xlo) || 1));
  const py = (v) => T + (H - T - B) * (1 - (v - ylo) / ((yhi - ylo) || 1));
  // 눈금은 반올림이 되는 값으로 (1·2·2.5·5 배수)
  const ticks = (lo, hi, count = 5) => {
    const span = hi - lo; if (!(span > 0)) return [lo];
    const raw = span / (count - 1), mag = Math.pow(10, Math.floor(Math.log10(raw)));
    const stepN = [1, 2, 2.5, 5, 10].find((m) => m * mag >= raw) || 10;
    const stepv = stepN * mag, first = Math.ceil(lo / stepv) * stepv, out = [];
    for (let v = first; v <= hi + stepv * 1e-9; v += stepv) out.push(+v.toFixed(10));
    return out.length >= 2 ? out : [lo, hi];
  };
  // 시도 라벨: 오른쪽 끝 점은 왼쪽에 쓰고, 세로로 겹치면 살짝 내려 쓴다
  const labels = level !== "sido" ? [] : (() => {
    let src = pts;
    if (narrowChart) {                                  // 좁은 화면: 다 쓰면 겹치므로 눈에 띄는 6곳만
      const byY = [...pts].sort((a, b) => a.y - b.y), byX = [...pts].sort((a, b) => a.x - b.x);
      const keep = new Set([byY[0], byY[byY.length - 1], byY[byY.length - 2], byX[0], byX[byX.length - 1]].filter(Boolean));
      src = pts.filter((p) => keep.has(p));
    }
    const out = src.map((p) => ({ p, x: px(p.x), y: py(p.y), t: p.r.n.replace(/특별자치도|특별자치시|광역시|특별시/, "") }))
      .sort((a, b) => a.y - b.y);
    const gap = narrowChart ? 11 : 12;
    out.forEach((o) => { o.right = o.x > W - R - 78; o.ty = o.y + 4; });
    for (let i = 1; i < out.length; i++) {
      const prev = out[i - 1];
      if (Math.abs(out[i].x - prev.x) < 74 && out[i].ty - prev.ty < gap) out[i].ty = prev.ty + gap;
    }
    return out;
  })();
  const sig = (p) => (p == null ? "" : p < 0.001 ? "***" : p < 0.01 ? "**" : p < 0.05 ? "*" : "");
  return (
    <div className="corr">
      <div className="card">
        <h3>연관지표 탐색 <small className="muted">두 지표의 관계 · 피어슨 · 스피어만 · 켄달</small></h3>
        <div className="desc">지역 단위(시도 17개 또는 시군구)에서 두 지표가 함께 움직이는지 봅니다. 점 하나가 지역 하나이며, ▶로 연도별 변화를 볼 수 있습니다. 상관은 인과가 아니며, 지역 수준의 관계(생태학적 관계)입니다.</div>
        <div className="ctrls" style={{ display: "flex", flexWrap: "wrap", gap: 8, margin: "8px 0" }}>
          <label className="subchip">X <Sel value={xId} onChange={setXId} /></label>
          <label className="subchip">Y <Sel value={yId} onChange={setYId} /></label>
          <label className="subchip">단위 <select value={level} onChange={(e) => setLevel(e.target.value)}><option value="sgg">시군구</option><option value="sido">17개 시도</option></select></label>
          {level === "sgg" && <label className="subchip">범위 <select value={sidoF} onChange={(e) => setSidoF(e.target.value)}><option value="all">전국</option>{SIDOS.map((s) => <option key={s.c} value={s.c}>{s.n}</option>)}</select></label>}
          <label className="subchip" title={slopeOk ? "" : `${yi.name}은 ${TREND_START}년 이후 5개 연도 이상 자료가 없어 기울기를 계산할 수 없습니다`}>Y 형태 <select value={ySlope ? "slope" : "value"} onChange={(e) => setYMode(e.target.value)}><option value="value">그해 값</option><option value="slope" disabled={!slopeOk}>10년 변화 기울기({TREND_START}~)</option></select></label>
          <label className="subchip">값 <select value={item} onChange={(e) => setItem(e.target.value)}><option value="std">표준화율</option><option value="crude">조율</option></select></label>
          <label className="subchip">연도 <button className="seg-btn" onClick={() => setPlay(!play)}>{play ? "■" : "▶"}</button> <select value={year} onChange={(e) => setYear(+e.target.value)}>{years.map((y) => <option key={y} value={y}>{y}</option>)}</select></label>
          <button type="button" className="seg-btn chip" onClick={preset} title="김동현 외(2025) 효과성 분석 연구의 핵심 결과를 우리 자료로 확인">연구 재현 예시: 재정자립도(2014) × 비만율 10년 기울기</button>
        </div>
        {ySlope && <div className="desc">Y는 지역마다 {TREND_START}~{yLast}년 {yi.name} 값에 직선을 맞춘 기울기(연간 변화량, {yUnit})입니다. 연도 선택은 X에만 적용됩니다. 연구에서는 기울기가 좋은 지역일수록 재정자립도가 높고 고령인구·독거노인 비율이 낮았습니다(지역 수준 관계 — 인과 아님).<Cite k="effect" /></div>}
      </div>
      <div className="grid2">
        <div className="card span2">
          <h3>{year}년 · {xi.name}<Cite ind={xi} /> × {yName}<Cite ind={yi} /> <small className="muted">(n={n})</small></h3>
          <ExportButtons name={`${year}_${xi.name}_x_${yi.name}_연관`} kinds={["svg", "png"]} />
          <div className="desc">X: {xi.name}({xi.unit}) · Y: {yName}({yUnit}) · 점선 = 최소제곱 추세선 · 점을 누르면 지역명{level === "sido" && narrowChart ? " · 좁은 화면에서는 양 끝 지역만 이름 표시" : ""}</div>
          <div ref={wrapRef}>
          {n < 3 ? <div className="empty">해당 연도에 두 지표를 모두 가진 지역이 없습니다</div> : (
            <svg className="chart" viewBox={`0 0 ${W} ${H}`} width={W} height={H} style={{ maxWidth: "100%" }} data-title={`${year} ${xi.name} × ${yi.name}`}>
              <defs><clipPath id="corr-clip"><rect x={L} y={T} width={W - L - R} height={H - T - B} /></clipPath></defs>
              {ticks(ylo, yhi).map((v) => <g key={"y" + v}><line x1={L} x2={W - R} y1={py(v)} y2={py(v)} stroke="var(--border)" /><text x={L - 6} y={py(v) + 4} fontSize="11.5" textAnchor="end" fill="var(--muted)">{fmt(v, ySlope ? 2 : 1)}</text></g>)}
              {ticks(xlo, xhi).map((v) => <g key={"x" + v}><line y1={T} y2={H - B} x1={px(v)} x2={px(v)} stroke="var(--border)" strokeOpacity="0.5" /><text x={px(v)} y={H - B + 14} fontSize="11.5" textAnchor="middle" fill="var(--muted)">{fmt(v)}</text></g>)}
              <text x={L + (W - L - R) / 2} y={H - 6} fontSize="12.5" textAnchor="middle" fill="var(--text-secondary)">{xi.name}</text>
              <text x={12} y={T + (H - T - B) / 2} fontSize="12.5" textAnchor="middle" fill="var(--text-secondary)" transform={`rotate(-90 12 ${T + (H - T - B) / 2})`}>{yName}</text>
              {n > 2 && (() => {                                   // 추세선은 그래프 안에서만 (축 밖으로 삐져나오지 않게)
                const x0 = Math.max(xlo, Math.min(...xs)), x1 = Math.min(xhi, Math.max(...xs));
                return <line x1={px(x0)} y1={py(my + slope * (x0 - mx))} x2={px(x1)} y2={py(my + slope * (x1 - mx))}
                  stroke="var(--bad-text)" strokeDasharray="5 4" strokeWidth="1.5" clipPath="url(#corr-clip)" />;
              })()}
              {pts.map((p) => (
                <circle key={p.r.c} cx={px(p.x)} cy={py(p.y)} r={level === "sido" ? 6 : 3.5} fill="var(--series-1)" fillOpacity="0.55" stroke="var(--surface-1)" strokeWidth="0.8"
                  onMouseMove={(ev) => { const { x, y } = clientXY(ev); setTip({ x, y, title: label(p.r), rows: [[xi.name, fmt(p.x) + xi.unit], [yName, fmt(p.y, ySlope ? 2 : 1) + yUnit]] }); }}
                  onMouseLeave={() => setTip(null)} />
              ))}
              {labels.map((o) => (
                <text key={"t" + o.p.r.c} x={o.right ? o.x - 9 : o.x + 8} y={o.ty} fontSize={narrowChart ? 10.5 : 11}
                  textAnchor={o.right ? "end" : "start"} fill="var(--text-secondary)"
                  paintOrder="stroke" stroke="var(--surface-1)" strokeWidth="2.4" strokeLinejoin="round">{o.t}</text>
              ))}
            </svg>
          )}
          </div>
        </div>
        <div className="card">
          <h3>연관성 통계</h3>
          <ExportButtons name={`${year}_${xi.name}_x_${yi.name}_상관`} kinds={["csv"]} />
          <div className="tblscroll"><table className="yeartbl">
            <thead><tr><th>방법</th><th>계수</th><th>p(근사)</th><th>판정</th></tr></thead>
            <tbody>
              <tr><td>피어슨 r</td><td>{fmt(rP, 3)}</td><td>{pP == null ? "–" : pP < 0.001 ? "<0.001" : fmt(pP, 3)}</td><td style={{ color: sig(pP) ? "var(--bad-text)" : undefined }}>{sig(pP) || "유의하지 않음"}</td></tr>
              <tr><td>스피어만 ρ</td><td>{fmt(rS, 3)}</td><td>{pS == null ? "–" : pS < 0.001 ? "<0.001" : fmt(pS, 3)}</td><td style={{ color: sig(pS) ? "var(--bad-text)" : undefined }}>{sig(pS) || "유의하지 않음"}</td></tr>
              <tr><td>켄달 τ-b</td><td>{fmt(tK, 3)}</td><td>{pK == null ? "–" : pK < 0.001 ? "<0.001" : fmt(pK, 3)}</td><td style={{ color: sig(pK) ? "var(--bad-text)" : undefined }}>{sig(pK) || "유의하지 않음"}</td></tr>
            </tbody>
          </table></div>
          <div className="desc" style={{ marginTop: 6 }}>* p&lt;0.05, ** p&lt;0.01, *** p&lt;0.001 (정규 근사). |r| 0.1 약함 · 0.3 중간 · 0.5 강함(Cohen). 추세선 기울기 {fmt(slope, 3)}: X가 1 오르면 Y가 {fmt(slope, 2)} 변함.</div>
        </div>
        <div className="card">
          <h3>연도별 상관 추이</h3>
          <div className="tblscroll"><table className="yeartbl">
            <thead><tr><th>연도</th><th>n</th><th>피어슨</th><th>스피어만</th></tr></thead>
            <tbody>
              {years.map((y) => { const q = pool.map((r) => [val(xi, item, y, r.c), yv(y, r.c)]).filter((v) => v[0] != null && v[1] != null); if (q.length < 3) return null; const a = q.map((v) => v[0]), b = q.map((v) => v[1]); return <tr key={y} className={y === year ? "sel" : ""} onClick={() => setYear(y)}><td>{y}</td><td>{q.length}</td><td>{fmt(pearson(a, b), 3)}</td><td>{fmt(q.length > 2 ? pearson(ranks(a), ranks(b)) : null, 3)}</td></tr>; })}
            </tbody>
          </table></div>
        </div>
      </div>
    </div>
  );
}
